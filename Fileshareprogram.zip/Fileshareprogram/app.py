import os
import uuid
import sqlite3
from flask import Flask, request, jsonify, send_from_directory, session, redirect, url_for, render_template, flash
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
import filetype

app = Flask(__name__)
app.secret_key = 'supersecretkey'
UPLOAD_FOLDER = 'uploads'
AVATAR_FOLDER = 'avatars'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['AVATAR_FOLDER'] = AVATAR_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(AVATAR_FOLDER, exist_ok=True)

messages = []


def init_db():
    with sqlite3.connect("database.db") as con:
        cur = con.cursor()
        cur.execute('''CREATE TABLE IF NOT EXISTS users (
            username TEXT PRIMARY KEY,
            password TEXT NOT NULL,
            tags TEXT,
            avatar TEXT
        )''')
        cur.execute('''CREATE TABLE IF NOT EXISTS files (
            id TEXT PRIMARY KEY,
            filename TEXT,
            owner TEXT,
            tags TEXT,
            type TEXT
        )''')
init_db()

def get_user_tags(username):
    with sqlite3.connect("database.db") as con:
        cur = con.cursor()
        cur.execute("SELECT tags FROM users WHERE username=?", (username,))
        row = cur.fetchone()
        return row[0].split(',') if row and row[0] else []

def get_user_avatar(username):
    with sqlite3.connect("database.db") as con:
        cur = con.cursor()
        cur.execute("SELECT avatar FROM users WHERE username=?", (username,))
        row = cur.fetchone()
        return row[0] if row and row[0] else None

def detect_file_type(file_path):
    kind = filetype.guess(file_path)
    if not kind:
        ext = os.path.splitext(file_path)[1].lower()
        if ext in ['.txt', '.md', '.json']:
            return "text"
        return "unknown"
    if kind.mime.startswith("video"):
        return "video"
    elif kind.mime.startswith("audio"):
        return "audio"
    elif kind.mime.startswith("image"):
        return "photo"
    else:
        return "unknown"

@app.route('/')
def home():
    return redirect(url_for('dashboard')) if 'username' in session else redirect(url_for('login'))

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        tags = ','.join(request.form.get('tags', '').split(','))

        avatar_file = request.files.get('avatar')
        avatar_filename = None
        if avatar_file and avatar_file.filename != '':
            avatar_filename = secure_filename(f"{uuid.uuid4()}_{avatar_file.filename}")
            avatar_path = os.path.join(app.config['AVATAR_FOLDER'], avatar_filename)
            avatar_file.save(avatar_path)

        with sqlite3.connect("database.db") as con:
            try:
                con.execute("INSERT INTO users (username, password, tags, avatar) VALUES (?, ?, ?, ?)",
                            (username, generate_password_hash(password), tags, avatar_filename))
                flash("Signup successful! Please log in.")
                return redirect(url_for('login'))
            except sqlite3.IntegrityError:
                flash("Username already exists.")
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        with sqlite3.connect("database.db") as con:
            cur = con.cursor()
            cur.execute("SELECT password FROM users WHERE username=?", (username,))
            row = cur.fetchone()
            if row and check_password_hash(row[0], password):
                session['username'] = username
                return redirect(url_for('dashboard'))
            else:
                flash("Invalid credentials.")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))

    files = []
    username = session['username']

    if request.method == 'POST':
        if 'file' in request.files:
            # Upload file
            file = request.files['file']
            tags = request.form['tags'].split(',')
            filename = secure_filename(file.filename)
            file_id = str(uuid.uuid4())
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file_id + "_" + filename)
            file.save(file_path)
            ftype = detect_file_type(file_path)
            with sqlite3.connect("database.db") as con:
                con.execute("INSERT INTO files (id, filename, owner, tags, type) VALUES (?, ?, ?, ?, ?)",
                            (file_id, filename, username, ','.join(tags), ftype))
            flash("File uploaded successfully.")

        elif 'newtags' in request.form:
            newtags = ','.join(request.form['newtags'].split(','))
            with sqlite3.connect("database.db") as con:
                con.execute("UPDATE users SET tags=? WHERE username=?", (newtags, username))
            flash("Tags updated.")

    search_query = request.args.get('search', '').lower()

    user_tags = get_user_tags(username)
    with sqlite3.connect("database.db") as con:
        cur = con.cursor()
        cur.execute("SELECT id, filename, owner, tags, type FROM files")
        for file_id, filename, owner, tags_str, ftype in cur.fetchall():
            file_tags = tags_str.split(',')
            visible = bool(set(user_tags) & set(file_tags))
            if visible and (search_query == '' or search_query in filename.lower() or any(search_query in t.lower() for t in file_tags)):
                files.append({
                    "id": file_id,
                    "filename": filename,
                    "owner": owner,
                    "tags": file_tags,
                    "type": ftype
                })
        cur.execute("SELECT tags FROM users WHERE username=?", (username,))
        row = cur.fetchone()
        current_tags = row[0] if row else ''
        avatar = get_user_avatar(username)

    return render_template('dashboard.html', files=files, username=username,
                           is_admin=(username == "Demir Gökler"),
                           current_tags=current_tags, avatar=avatar, search=search_query)

@app.route('/download/<file_id>')
def download_file(file_id):
    if 'username' not in session:
        return redirect(url_for('login'))

    with sqlite3.connect("database.db") as con:
        cur = con.cursor()
        cur.execute("SELECT filename FROM files WHERE id=?", (file_id,))
        row = cur.fetchone()
        if not row:
            return "File not found", 404
        filename = row[0]
        full_filename = f"{file_id}_{filename}"
        return send_from_directory(app.config['UPLOAD_FOLDER'], full_filename, as_attachment=True)

@app.route('/avatars/<filename>')
def get_avatar(filename):
    return send_from_directory(app.config['AVATAR_FOLDER'], filename)

@app.route('/admin', methods=['GET', 'POST'])
def admin_panel():
    if 'username' not in session or session['username'] != "Demir Gökler":
        return redirect(url_for('dashboard'))

    users = []
    files = []

    with sqlite3.connect("database.db") as con:
        cur = con.cursor()

        if request.method == 'POST':
            uid = request.form['username']
            newtags = ','.join(request.form['newtags'].split(','))
            cur.execute("UPDATE users SET tags=? WHERE username=?", (newtags, uid))
            flash(f"Tags updated for {uid}")

        cur.execute("SELECT username, tags, avatar FROM users")
        users = cur.fetchall()

        cur.execute("SELECT id, filename, owner, tags, type FROM files")
        files = cur.fetchall()

    return render_template('admin.html', users=users, files=files)

@app.route('/delete_file/<file_id>', methods=['POST'])
def delete_file(file_id):
    if 'username' not in session or session['username'] != "Demir Gökler":
        return redirect(url_for('dashboard'))

    with sqlite3.connect("database.db") as con:
        cur = con.cursor()
        cur.execute("SELECT filename FROM files WHERE id=?", (file_id,))
        row = cur.fetchone()
        if row:
            filename = row[0]
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], f"{file_id}_{filename}")
            if os.path.exists(filepath):
                os.remove(filepath)
        con.execute("DELETE FROM files WHERE id=?", (file_id,))
    flash("File deleted.")
    return redirect(url_for('admin_panel'))


def main():
    app.run(host='0.0.0.0', port=5001, debug=True)

if __name__ == '__main__':
    main()
