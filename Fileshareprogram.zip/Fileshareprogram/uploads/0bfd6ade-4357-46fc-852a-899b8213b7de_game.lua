-- game.lua
local board = require("board")
local pieces = require("pieces")

local game = {}
local currentPlayer = 1
local mana = {1, 1}  -- Mana for player 1 and player 2
local turn = 1
local maxMana = 6
local boardSize = 8
local pieceSize = 64  -- Size of each piece (in pixels)

function game.load()
    board.load(boardSize, pieceSize)
    pieces.load()
end

function game.update(dt)
    -- Update logic here (e.g., animations, timers)
end

function game.draw()
    board.draw()
    pieces.draw()
    
    -- Draw mana status
    love.graphics.print("Player 1 Mana: " .. mana[1], 10, 10)
    love.graphics.print("Player 2 Mana: " .. mana[2], 10, 30)
end

function game.mousepressed(x, y, button)
    if button == 1 then
        pieces.selectPiece(x, y, currentPlayer)
    end
end

function game.endTurn()
    currentPlayer = 3 - currentPlayer  -- Switch between 1 and 2
    turn = turn + 1
    
    -- Increase mana for each player
    mana[1] = math.min(turn, maxMana)
    mana[2] = math.min(turn, maxMana)
end

return game
