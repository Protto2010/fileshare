from setuptools import setup

setup(
    name='file_sharing_server',
    version='1.0',
    packages=[''],
    install_requires=[
        'Flask==2.3.2',
        'filetype==1.2.0',
        'Werkzeug==2.3.7'
    ],
    entry_points={
        'console_scripts': [
            'runfileshare=app:main',
        ],
    },
)
